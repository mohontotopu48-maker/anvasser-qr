import { ChecklistItem, Language, UIContent } from './types';

export const checklistData: Record<Language, ChecklistItem[]> = {
  en: [
    {
      id: 1,
      title: 'The "Active" Status Trap',
      mistake: "Verifying a license number but failing to check for Active Workers’ Comp.",
      danger: "If a worker is injured on your property and the insurance has lapsed, the financial liability falls directly on your home equity. You could lose your home over a roofer's injury.",
      standard: "We are fully licensed, bonded, and insured (CA License #1122623) and keep our standing \"Gold-Level\" active for your total protection."
    },
    {
      id: 2,
      title: 'The "Instant Start" Trap',
      mistake: "Hiring a roofer who promises to \"tear off the roof tomorrow\" to bypass your right to think.",
      danger: "Predatory roofers use speed to \"lock you in\" before you can exercise your legal right to cancel under CA Civil Code 1689.6 and AB 2471.",
      standard: "We strictly honor your rights: a 3-business-day right to cancel for those under 65, and a 5-business-day period for seniors (65+). We never \"trap\" you."
    },
    {
      id: 3,
      title: 'The "Surface-Fix" Low-Ball Quote',
      mistake: "Choosing the cheapest bid only to have the price skyrocket once the roof is removed.",
      danger: "You are held hostage with an open roof and \"unforeseen\" costs that can add thousands to your final bill.",
      standard: "We provide Upfront Integrity Pricing by identifying core issues before we start so the price we quote is the price you pay."
    },
    {
      id: 4,
      title: 'The "Protection" Gap',
      mistake: "Hiring non-certified labor and ignoring job site safety.",
      danger: "Non-certified installs void your 30-year warranty instantly. Additionally, sloppy crews leave sharp nails that threaten your family’s tires and pets.",
      standard: "We are Factory Trained and Certified to guarantee your warranty and perform Triple-Pass Magnetic Sweeps to keep your yard safe."
    },
    {
      id: 5,
      title: 'Ignoring the "Core Problem"',
      mistake: "Fixing a visible leak but ignoring structural rot or ventilation issues.",
      danger: "The underlying rot continues to spread, meaning your expensive new shingles will fail and the leak will return within months.",
      standard: "Our Two-Step Strategy finds the core problem first, ensuring a permanent repair rather than a temporary \"band-aid.\""
    },
    {
      id: 6,
      title: 'Attic Ventilation "Suffocation"',
      mistake: "Focusing only on shingles and ignoring attic airflow.",
      danger: "Heat builds up and \"cooks\" your roof from the inside out, skyrocketing your energy bills and cutting your roof's lifespan in half.",
      standard: "We perform a full ventilation audit to lower energy costs and ensure your roof can \"breathe\" in the SoCal heat."
    },
    {
      id: 7,
      title: 'Overlooking Curb Appeal',
      mistake: "Letting contractors place ugly vents on the front of your house for their convenience.",
      danger: "Poorly placed vents create \"roof clutter\" that kills your home's curb appeal and can lower your property value.",
      standard: "We prioritize Aesthetic Engineering, placing vents strategically in the back to protect your home's Southern California style."
    },
    {
      id: 8,
      title: 'Hiring Without an "Accident Protocol"',
      mistake: "Hiring roofers who don't have a formal process for handling onsite mishaps.",
      danger: "Most roofers hide small accidents like a cracked tile or nicked gutter; you don't find the damage until they are long gone.",
      standard: "We have an Immediate Transparency Policy; if an accident happens, we call you immediately and fix it on our dime."
    },
    {
      id: 9,
      title: 'The "Leftover" Equipment Headache',
      mistake: "Allowing roofers to handle your tech (satellite dishes/antennas) without a plan.",
      danger: "Roofers often rip off old equipment and leave it as trash in your yard or improperly re-mount it, killing your signal.",
      standard: "We coordinate the removal or adjustment of your tech so your property stays clean and your service isn't interrupted."
    },
    {
      id: 10,
      title: 'Skipping the City Guideline Audit',
      mistake: "Ignoring local OC/LA building permits to save time or a few bucks.",
      danger: "This leads to massive city fines, \"stop-work\" orders, and major headaches when you eventually try to sell your home.",
      standard: "We ensure every roof is 100% City Compliant and built strictly to the latest local building codes."
    },
    {
      id: 11,
      title: 'Hiring "Anonymous" Sub-Contractors',
      mistake: "Hiring a company that \"sells\" the job and then hands it off to a random crew.",
      danger: "You lose accountability; the person you trusted isn't the one actually building the roof that protects your family.",
      standard: "We are The Neighborhood Choice. We manage every step with our own specialized experts—we never \"sub out\" your trust."
    },
    {
      id: 12,
      title: 'The "Ghosting" Phase',
      mistake: "Hiring a roofer with no post-deposit communication system.",
      danger: "Once the check is signed, the salesman disappears, leaving you in the dark about timelines and project status.",
      standard: "We use technology-driven partnership to stay in constant contact. We stay around even after the work is done to give you peace of mind."
    },
    {
      id: 13,
      title: 'Using Low-Quality Underlayment',
      mistake: "Choosing standard felt paper instead of modern synthetics.",
      danger: "Standard felt paper tears and rots easily; if a shingle blows off, your home has zero secondary protection against water.",
      standard: "We only use Premium Synthetic Underlayment to provide a high-performance, tear-resistant waterproof barrier."
    },
    {
      id: 14,
      title: 'Landscaping "Splatter Zone" Damage',
      mistake: "Not requiring a property protection plan for your yard.",
      danger: "Thousands of pounds of falling debris can crush expensive rose bushes, landscaping, and irrigation systems.",
      standard: "We use specialized shields and debris management to protect your landscaping during the entire tear-off process."
    },
    {
      id: 15,
      title: 'Re-using Old, Rusty Flashing',
      mistake: "Allowing the contractor to keep your old metal flashing around chimneys and walls.",
      danger: "Old flashing is the #1 cause of leaks; re-using it is like putting old tires on a brand-new Ferrari.",
      standard: "We replace all critical flashing with new, high-grade metal to ensure a 100% watertight seal."
    },
    {
      id: 16,
      title: 'Lack of Daily Clean-up Routine',
      mistake: "Hiring a crew that only cleans up at the very end of the job.",
      danger: "Your home becomes a dangerous construction zone for a week, with nails in the driveway and granules in your pool.",
      standard: "We perform a meticulous End-of-Day Clean-up every single day to keep your home livable and safe."
    },
    {
      id: 17,
      title: 'Shingle "Layering" Limits',
      mistake: "Adding a new layer of shingles over an old one to \"save money.\"",
      danger: "This adds thousands of pounds of dangerous weight to your home’s structure and prevents us from inspecting the wood deck for rot.",
      standard: "We always recommend a full tear-off to inspect the structural integrity of your home’s decking."
    },
    {
      id: 18,
      title: 'Accepting "Verbal" Change Orders',
      mistake: "Agreeing to extra work or costs over a simple handshake.",
      danger: "Without a paper trail, you have no protection against \"billing creep\" or disputes when the final invoice arrives.",
      standard: "All changes are documented and approved digitally through our GHL system so there are never any surprises."
    },
    {
      id: 19,
      title: 'Improper Nailing Patterns',
      mistake: "Hiring crews who rush the installation by \"high-nailing\" shingles.",
      danger: "Improperly nailed shingles lack wind resistance and will blow off during the next high-wind event in OC or LA.",
      standard: "Our crews follow strict, factory-certified nailing patterns to ensure maximum wind warranty protection."
    },
    {
      id: 20,
      title: 'Paying Too Much Upfront',
      mistake: "Giving a contractor a massive down payment (50%+) before work begins.",
      danger: "You lose all your leverage; if the contractor disappears or delays the job, your money is gone.",
      standard: "We follow California CSLB guidelines for down payments, ensuring you keep the leverage until your project is underway."
    }
  ],
  es: [
    {
      id: 1,
      title: 'La Trampa del Estado "Activo"',
      mistake: "Verificar un número de licencia pero no comprobar el Seguro de Compensación para Trabajadores activo.",
      danger: "Si un trabajador se lesiona en su propiedad y su seguro ha caducado, la responsabilidad financiera recae directamente sobre usted.",
      standard: "Estamos totalmente licenciados, afianzados y asegurados (Licencia CA #1122623). Mantenemos el estatus activo \"Gold-Level\" para su protección total."
    },
    {
      id: 2,
      title: 'La Trampa del "Inicio Instantáneo"',
      mistake: "Contratar a un techador que promete \"quitar el techo mañana\" para anular su derecho a pensar.",
      danger: "Los techadores depredadores usan la velocidad para \"atraparlo\" antes de que pueda ejercer su derecho legal de cancelación bajo el Código Civil de CA 1689.6.",
      standard: "Respetamos estrictamente sus derechos: 3 días de derecho a cancelar (menores de 65) y 5 días para personas mayores (65+)."
    },
    {
      id: 3,
      title: 'La Trampa del Presupuesto Bajo',
      mistake: "Elegir la oferta más barata solo para que el precio se dispare una vez que se quita el techo y se encuentran problemas \"imprevistos\".",
      danger: "Usted queda como rehén con un techo abierto y costos que pueden agregar miles a su factura final sin previo aviso.",
      standard: "SNEWROOF ofrece Precios de Integridad por Adelantado. Identificamos los problemas principales antes de comenzar para que el precio cotizado sea el que pague."
    },
    {
      id: 4,
      title: 'La Brecha de Protección',
      mistake: "Contratar mano de obra no certificada e ignorar los protocolos de seguridad.",
      danger: "Las instalaciones no certificadas anulan su garantía de 30 años al instante. Los equipos descuidados dejan clavos peligrosos en su entrada.",
      standard: "Los equipos de SNEWROOF están capacitados y certificados por la fábrica. Realizamos barridos magnéticos de triple pasada para mantener su patio seguro."
    },
    {
      id: 5,
      title: 'Ignorar el "Problema de Raíz"',
      mistake: "Reparar una filtración visible pero ignorar la podredumbre estructural o problemas de ventilación.",
      danger: "La podredumbre subyacente continúa extendiéndose, lo que significa que su costoso techo nuevo fallará y la filtración volverá en pocos meses.",
      standard: "Nuestra Estrategia de Dos Pasos encuentra primero el problema central, asegurando una reparación permanente en lugar de un \"parche\" temporal."
    },
    {
      id: 6,
      title: 'Asfixia por Ventilación del Ático',
      mistake: "Centrarse solo en las tejas e ignorar los requisitos de flujo de aire del ático.",
      danger: "El calor se acumula y \"cocina\" su techo desde adentro, disparando sus facturas de energía y reduciendo la vida útil a la mitad.",
      standard: "Realizamos una auditoría de ventilación completa para reducir costos y asegurar que su techo pueda \"respirar\" en el calor del sur de California."
    },
    {
      id: 7,
      title: 'Ignorar el Atractivo Visual',
      mistake: "Permitir que coloquen ventilaciones feas en el frente de su casa por conveniencia del contratista.",
      danger: "Las ventilaciones mal colocadas arruinan el atractivo visual y pueden reducir el valor de su propiedad.",
      standard: "Priorizamos la Ingeniería Estética, colocando las ventilaciones estratégicamente para proteger el estilo de su hogar."
    },
    {
      id: 8,
      title: 'Contratar sin Protocolo de Accidentes',
      mistake: "Contratar techadores que no tienen un proceso formal para manejar percances en el sitio.",
      danger: "La mayoría de los techadores ocultan pequeños accidentes; usted no descubre el daño hasta que se han ido.",
      standard: "SNEWROOF mantiene una Política de Transparencia Inmediata. Si ocurre un accidente, le llamamos de inmediato y lo arreglamos nosotros."
    },
    {
      id: 9,
      title: 'El Dolor de Cabeza del Equipo Tecnológico',
      mistake: "Permitir que manejen tecnología (antenas satelitales) sin un plan claro.",
      danger: "A menudo arrancan equipos viejos y los dejan como basura o los montan mal, arruinando su señal.",
      standard: "Coordinamos el retiro o ajuste de su tecnología para que su propiedad se mantenga limpia y su servicio continúe sin interrupciones."
    },
    {
      id: 10,
      title: 'Omitir Permisos Municipales',
      mistake: "Ignorar los permisos locales de OC/LA para ahorrar tiempo o dinero.",
      danger: "Esto conlleva multas municipales masivas, órdenes de detención de obra y problemas cuando intente vender su casa.",
      standard: "SNEWROOF garantiza que cada techo sea 100% conforme con los códigos de construcción locales más recientes."
    },
    {
      id: 11,
      title: 'Contratar Sub-contrataciones "Anónimas"',
      mistake: "Contratar a una empresa que \"vende\" el trabajo y luego lo entrega a un equipo desconocido.",
      danger: "Usted pierde la responsabilidad; la persona en la que confió no es la que construye el techo que protege a su familia.",
      standard: "Gestionamos cada paso con nuestros propios expertos especializados; nunca subcontratamos su confianza a extraños."
    },
    {
      id: 12,
      title: 'La Fase de Abandono (Ghosting)',
      mistake: "Contratar a un techador sin un sistema de comunicación tras el depósito.",
      danger: "Una vez firmado el cheque, el vendedor desaparece, dejándolo en la oscuridad sobre los plazos y el estado del proyecto.",
      standard: "Usamos tecnología para mantener contacto constante. Estamos presentes incluso después de terminar la obra."
    },
    {
      id: 13,
      title: 'Contrapiso de Baja Calidad',
      mistake: "Elegir papel de fieltro estándar en lugar de sintéticos modernos.",
      danger: "El fieltro estándar se rompe y se pudre fácilmente; si una teja se vuela, su hogar queda sin protección secundaria.",
      standard: "Solo usamos Contrapiso Sintético Premium para una barrera impermeable superior y resistente a desgarros."
    },
    {
      id: 14,
      title: 'Daños en el Jardín',
      mistake: "No exigir un plan de protección de la propiedad para su jardín.",
      danger: "Miles de libras de escombros pueden aplastar plantas costosas y sistemas de riego.",
      standard: "Usamos protectores especializados y gestión de escombros para cuidar su jardín durante todo el proceso de remoción."
    },
    {
      id: 15,
      title: 'Reutilización de Tapajuntas Viejos',
      mistake: "Permitir que conserven los tapajuntas metálicos viejos y oxidados.",
      danger: "Los tapajuntas viejos son la causa #1 de filtraciones; reutilizarlos es un error crítico.",
      standard: "SNEWROOF reemplaza todos los tapajuntas críticos con metal nuevo de alta calidad para un sello 100% hermético."
    },
    {
      id: 16,
      title: 'Limpieza Meticulosa Diaria',
      mistake: "Contratar a un equipo que solo limpia al final del trabajo.",
      danger: "Su hogar se vuelve una zona de construcción peligrosa durante una semana, con clavos y escombros por todas partes.",
      standard: "Realizamos una limpieza meticulosa cada día para mantener su hogar habitable y su familia segura."
    },
    {
      id: 17,
      title: 'Límites de Capas de Tejas',
      mistake: "Agregar una nueva capa de tejas sobre una vieja para \"ahorrar dinero\".",
      danger: "Esto agrega peso peligroso a su estructura y oculta la podredumbre de la madera.",
      standard: "Siempre recomendamos un retiro total para inspeccionar la integridad estructural de la base de su techo."
    },
    {
      id: 18,
      title: 'Órdenes de Cambio Verbales',
      mistake: "Acordar trabajos o costos adicionales con un simple apretón de manos.",
      danger: "Sin un registro escrito, no tiene protección contra el aumento de costos o disputas cuando llegue la factura final.",
      standard: "Todos los cambios se documentan y aprueban digitalmente para que no haya sorpresas inesperadas."
    },
    {
      id: 19,
      title: 'Patrones de Clavado Incorrectos',
      mistake: "Equipos que clavan las tejas demasiado alto por ir de prisa.",
      danger: "Las tejas mal clavadas carecerán de resistencia contra el viento y se volarán durante el próximo viento fuerte.",
      standard: "Nuestros equipos siguen patrones de clavado certificados para máxima resistencia y protección de garantía."
    },
    {
      id: 20,
      title: 'Pagar Demasiado por Adelantado',
      mistake: "Dar a un contratista un pago inicial masivo (50%+) antes de que comience el trabajo.",
      danger: "Usted pierde toda su ventaja; si el contratista desaparece o retrasa el trabajo, su dinero se ha ido.",
      standard: "SNEWROOF sigue las pautas de la CSLB de California para pagos iniciales, asegurando que usted mantenga el control hasta que el proyecto esté en marcha."
    }
  ]
};

export const uiContent: Record<Language, UIContent> = {
  en: {
    fullAccess: "The SNEWROOF Homeowner’s Shield Checklist",
    heroTitle: "20 Expensive Mistakes to Avoid ",
    heroTitleAccent: "When Hiring a Roofer",
    heroDesc: "The SNEWROOF Homeowner’s Shield Checklist",
    heroDescEmphasis: "Protect your family and your home equity. See the full explanation for the 20 critical protection gaps roofers usually ignore.",
    ctaAudit: "Unlock the Full Shield",
    ctaExplore: "Free Preview Below",
    scrollDown: "Free Preview Below",
    checklistHeading: "The Complete 20-Point Checklist",
    checklistSubheading: "The full definitive guide to protect your family and your home equity.",
    differenceTag: "The SNEWROOF Standard",
    differenceHeading: "We prioritize your protection over our convenience.",
    differenceDesc: "We built this checklist because we believe homeowners deserve better. In an industry often plagued by shortcuts, we choose transparency.",
    standardLabels: {
      mistake: "The Mistake",
      danger: "The Danger",
      standard: "The SNEWROOF Standard",
      commitment: "Our Commitment",
      contact: "Consult Specialist"
    },
    formLabels: {
      sectionTitle: "Unlock the Full Shield Checklist",
      sectionDesc: "Enter your info below to receive the complete 20-point checklist sent instantly to your device.",
      name: "Full Name",
      email: "Email Address",
      phone: "Phone Number",
      message: "Optional Property Address",
      submit: "Unlock All 20 Mistakes",
      submitting: "Authorizing..."
    },
    formMessages: {
      success: "Access Granted. Redirecting to SNEWROOF Official Portal...",
      redirecting: "Stand by while we connect you to our full technical resources.",
      error: "Something went wrong. Please try again or call 714-770-4756."
    },
    valueProps: {
      licensedTitle: "Licensed & Bonded",
      licensedDesc: "CA License #1122623. We carry full workers' comp and liability insurance for your safety.",
      graceTitle: "3-5 Day Grace",
      graceDesc: "We never rush you. We strictly follow legal cancellation periods to ensure your confidence.",
      factoryTitle: "Factory Certified",
      factoryDesc: "Installation protocols that exceed manufacturer standards to protect your 30-year warranty."
    },
    finalCtaTitle: "Ready for an Honest Assessment? ",
    finalCtaAccent: "Book Your Shield Audit.",
    finalCtaDesc: "Get a professional 20-point SNR Shield Inspection today. We'll show you exactly where your home stands.",
    finalCtaButton: "Book Free Inspection",
    footerTagline: "Reinventing the roofing experience through integrity, technology, and superior standards.",
    footerLinks: {
      checklist: "Checklist",
      difference: "The Standard",
      process: "Process",
      about: "About",
      contact: "Contact"
    },
    phoneLabel: "714-770-4756",
    bookButton: "Book Audit"
  },
  es: {
    fullAccess: "La Lista de Control SNR de SNEWROOF",
    heroTitle: "20 Errores Costosos a Evitar ",
    heroTitleAccent: "al Contratar un Techador",
    heroDesc: "La Lista de Control SNEWROOF",
    heroDescEmphasis: "Proteja a su familia y su patrimonio. Vea la explicación completa de los 20 errores críticos que los techadores suelen ignorar.",
    ctaAudit: "Desbloquear el Escudo SNR",
    ctaExplore: "Vista Previa Abajo",
    scrollDown: "Vista Previa Abajo",
    checklistHeading: "La Lista Completa de 20 Puntos",
    checklistSubheading: "La guía definitiva para proteger su patrimonio y a su familia.",
    differenceTag: "El Estándar SNEWROOF",
    differenceHeading: "Priorizamos su protección sobre nuestra conveniencia.",
    differenceDesc: "Creamos esta lista porque creemos que los propietarios merecen algo mejor. En una industria de atajos, elegimos la transparencia.",
    standardLabels: {
      mistake: "El Error",
      danger: "El Peligro",
      standard: "El Estándar SNEWROOF",
      commitment: "Nuestro Compromiso",
      contact: "Consultar Especialista"
    },
    formLabels: {
      sectionTitle: "Desbloquee la Lista SNR Shield",
      sectionDesc: "Ingrese su información para recibir la lista completa de 20 puntos enviada al instante a su dispositivo.",
      name: "Nombre Completo",
      email: "Correo Electrónico",
      phone: "Número de Teléfono",
      message: "Dirección (Opcional)",
      submit: "Desbloquear los 20 Errores",
      submitting: "Autorizando..."
    },
    formMessages: {
      success: "Acceso Concedido. Redirigiendo al Portal Oficial de SNEWROOF...",
      redirecting: "Espere un momento mientras le conectamos con nuestros recursos técnicos.",
      error: "Algo salió mal. Intente de nuevo o llame al 714-770-4756."
    },
    valueProps: {
      licensedTitle: "Licencia y Seguro",
      licensedDesc: "CA #1122623. Contamos con compensación laboral y seguros de responsabilidad para su seguridad.",
      graceTitle: "Gracia de 3-5 Días",
      graceDesc: "Nunca le apuramos. Respetamos los periodos legales de cancelación para su confianza.",
      factoryTitle: "Certificado de Fábrica",
      factoryDesc: "Protocolos de instalación que superan los estándares para proteger su garantía de 30 años."
    },
    finalCtaTitle: "¿Listo para una Evaluación Honesta? ",
    finalCtaAccent: "Reserve su Auditoría Shield.",
    finalCtaDesc: "Obtenga una inspección profesional SNR Shield hoy mismo. Le mostraremos exactamente el estado de su techo.",
    finalCtaButton: "Reservar Inspección Gratis",
    footerTagline: "Reinventando el techado con integridad, tecnología y estándares superiores.",
    footerLinks: {
      checklist: "Lista de Control",
      difference: "El Estándar",
      process: "Proceso",
      about: "Nosotros",
      contact: "Contacto"
    },
    phoneLabel: "714-770-4756",
    bookButton: "Reservar Auditoría"
  }
};