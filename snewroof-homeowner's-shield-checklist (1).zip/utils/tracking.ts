declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

export const trackEvent = (eventName: string, params?: Record<string, any>) => {
  try {
    // Check if window exists and gtag is available (it might be blocked by ad blockers)
    if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
      window.gtag('event', eventName, params);
    } else {
      // In development, log the event to console if GA is not loaded
      // Using 'as any' to bypass TypeScript error if vite-env.d.ts is missing
      if ((import.meta as any).env?.DEV) {
        console.debug('[Analytics-Dev]', eventName, params);
      }
    }
  } catch (error) {
    // Use warn instead of error to avoid cluttering production logs
    console.warn('Analytics tracking error:', error);
  }
};