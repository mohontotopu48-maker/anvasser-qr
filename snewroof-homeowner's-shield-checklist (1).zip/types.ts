
export interface ChecklistItem {
  id: number;
  title: string;
  mistake: string;
  danger?: string;
  standard: string;
  commitment?: string;
}

export type Language = 'en' | 'es';

export interface UIContent {
  fullAccess: string;
  heroTitle: string;
  heroTitleAccent: string;
  heroDesc: string;
  heroDescEmphasis: string;
  ctaAudit: string;
  ctaExplore: string;
  scrollDown: string;
  checklistHeading: string;
  checklistSubheading: string;
  differenceTag: string;
  differenceHeading: string;
  differenceDesc: string;
  standardLabels: {
    mistake: string;
    danger: string;
    standard: string;
    commitment: string;
    contact: string;
  };
  formLabels: {
    sectionTitle: string;
    sectionDesc: string;
    name: string;
    email: string;
    phone: string;
    message: string;
    submit: string;
    submitting: string;
  };
  formMessages: {
    success: string;
    redirecting: string;
    error: string;
  };
  valueProps: {
    licensedTitle: string;
    licensedDesc: string;
    graceTitle: string;
    graceDesc: string;
    factoryTitle: string;
    factoryDesc: string;
  };
  finalCtaTitle: string;
  finalCtaAccent: string;
  finalCtaDesc: string;
  finalCtaButton: string;
  footerTagline: string;
  footerLinks: {
    checklist: string;
    difference: string;
    process: string;
    about: string;
    contact: string;
  };
  phoneLabel: string;
  bookButton: string;
}
