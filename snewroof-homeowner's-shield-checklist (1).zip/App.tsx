import React, { useState, useRef, useEffect } from 'react';
import { Button } from './components/Button';
import { ChecklistCard } from './components/ChecklistCard';
import { LeadForm } from './components/LeadForm';
import { Header } from './components/Header';
import { MistakesPage } from './components/MistakesPage';
import { checklistData, uiContent } from './data';
import { Language } from './types';
import { trackEvent } from './utils/tracking';

const BOOKING_URL = "https://api.leadconnectorhq.com/widget/bookings/free-roof-inspection-snewroof";

export const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('en');
  const [isUnlocked, setIsUnlocked] = useState(() => {
    // Check URL parameters for direct unlock access (e.g. from email links)
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get('unlocked') === 'true';
    }
    return false;
  });
  
  const formRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isUnlocked) {
      trackEvent('checklist_unlocked', { method: 'url_param_or_submission' });
    } else {
      trackEvent('page_view_landing');
    }
  }, [isUnlocked]);

  const handleBookInspection = () => {
    trackEvent('book_inspection_click', { location: 'landing_hero' });
    window.location.href = BOOKING_URL;
  };

  const handleDownloadClick = () => {
    trackEvent('read_mistakes_scroll');
    formRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  // Handler for users who are already registered or want to bypass
  const handleDirectAccess = () => {
    trackEvent('direct_access_click');
    setIsUnlocked(true);
    window.scrollTo(0, 0);
  };
  
  // Handler for successful form submission via LeadConnector
  const handleUnlock = () => {
    trackEvent('form_submission_unlocked');
    setIsUnlocked(true);
    window.scrollTo(0, 0);
  };

  const handleShare = (platform: 'facebook' | 'twitter' | 'linkedin' | 'email' | 'whatsapp' | 'copy') => {
    trackEvent('share_click', { platform, location: 'sticky_bar' });

    const url = window.location.href.split('?')[0];
    const text = "Protect your home equity. 20 Expensive Mistakes to Avoid When Hiring a Roofer - The SNEWROOF Shield Checklist.";
    
    if (platform === 'copy') {
      navigator.clipboard.writeText(url);
      alert('Link copied to clipboard!');
      return;
    }

    let shareUrl = '';
    const encodedUrl = encodeURIComponent(url);
    const encodedText = encodeURIComponent(text);

    switch (platform) {
      case 'facebook': shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`; break;
      case 'twitter': shareUrl = `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`; break;
      case 'linkedin': shareUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${encodedUrl}&title=${encodeURIComponent("SNR Shield Checklist")}&summary=${encodedText}`; break;
      case 'whatsapp': shareUrl = `https://api.whatsapp.com/send?text=${encodedText}%20${encodedUrl}`; break;
      case 'email': shareUrl = `mailto:?subject=Important Homeowner Guide&body=${encodedText}%0A%0A${encodedUrl}`; break;
    }
    
    if (shareUrl) window.open(shareUrl, '_blank', 'width=600,height=400');
  };

  // View: Unlocked Content (Full Checklist)
  if (isUnlocked) {
    return <MistakesPage lang={lang} />;
  }

  // View: Locked Landing Page (Teaser + Form)
  const top3Items = checklistData[lang].slice(0, 3);
  const content = uiContent[lang];

  return (
    <div className="min-h-screen flex flex-col bg-white pb-32 relative">
      <div className="fixed inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] pointer-events-none z-0"></div>
      
      {/* Desktop Sticky Share Bar */}
      <div className="fixed left-6 top-1/2 -translate-y-1/2 z-40 hidden xl:flex flex-col gap-3 bg-white p-3 rounded-2xl shadow-[0_5px_30px_rgba(0,0,0,0.1)] border border-slate-100 animate-fade-in print:hidden">
         <span className="text-[10px] font-bold text-slate-400 text-center uppercase tracking-widest writing-vertical-lr py-2">Share Guide</span>
         <button onClick={() => handleShare('facebook')} className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center" aria-label="Share on Facebook">
           <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
         </button>
         <button onClick={() => handleShare('twitter')} className="w-10 h-10 rounded-full bg-slate-50 text-slate-900 hover:bg-black hover:text-white transition-all flex items-center justify-center" aria-label="Share on Twitter">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
         </button>
         <button onClick={() => handleShare('linkedin')} className="w-10 h-10 rounded-full bg-blue-50 text-[#0077b5] hover:bg-[#0077b5] hover:text-white transition-all flex items-center justify-center" aria-label="Share on LinkedIn">
           <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z"/></svg>
         </button>
         <button onClick={() => handleShare('whatsapp')} className="w-10 h-10 rounded-full bg-green-50 text-[#25D366] hover:bg-[#25D366] hover:text-white transition-all flex items-center justify-center" aria-label="Share on WhatsApp">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.355-5.233c-.002-5.45 4.43-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
         </button>
      </div>

      <div className="relative z-10">
        <Header 
           lang={lang} 
           onLanguageChange={(l) => {
             trackEvent('language_change', { language: l });
             setLang(l);
           }} 
           onBook={handleBookInspection}
        />

        <main className="flex-grow">
          {/* Intro Message & Hero Buttons */}
          <section className="container max-w-xl mx-auto px-6 text-center mb-16 animate-fade-in">
            <p className="text-sm sm:text-base font-medium text-slate-500 max-w-sm mx-auto leading-relaxed mb-8">
              {content.heroDescEmphasis}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
               <Button 
                 variant="outline"
                 size="sm"
                 onClick={handleDownloadClick}
                 className="border-none hover:bg-transparent hover:text-[#FF8C00] text-slate-400"
               >
                 Read The Mistakes
               </Button>
            </div>
          </section>

          {/* Top 3 Teaser Cards */}
          <section className="container max-w-xl mx-auto px-6 space-y-8">
            <div className="text-center mb-8">
               <h3 className="text-2xl font-black text-[#FF8C00]">The "Top 3" Mistakes</h3>
               <div className="w-12 h-1 bg-slate-100 mx-auto mt-2"></div>
            </div>

            {top3Items.map((item, idx) => (
              <div key={item.id} className="animate-fade-in" style={{ animationDelay: `${idx * 100}ms` }}>
                <ChecklistCard item={item} lang={lang} />
                
                {/* Teaser Bridge Text */}
                {idx === 2 && (
                  <div className="mt-16 mb-8 text-center animate-fade-in">
                     <div className="max-w-md mx-auto bg-orange-50/50 border border-orange-100 rounded-2xl p-6 relative">
                       <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white px-3 py-1 rounded-full border border-orange-100 shadow-sm">
                         <svg className="w-4 h-4 text-[#FF8C00]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                       </div>
                       <p className="text-sm font-medium text-slate-800 leading-relaxed italic">
                         "I’ve shared the first 3, but the next 17 mistakes involve <strong>The 'Protection' Gap (Voided Warranties & Nail Minefields)</strong>, city compliance, and property safety. Enter your info below to get the full SNR Homeowner's Shield Checklist sent to your phone/inbox instantly."
                       </p>
                     </div>
                     
                     <div className="mt-8 flex justify-center">
                        <svg className="w-6 h-6 text-slate-300 animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path></svg>
                     </div>
                  </div>
                )}
              </div>
            ))}

            {/* Lead Form Section */}
            <section id="unlock-form" ref={formRef} className="py-12 relative z-20">
                <LeadForm lang={lang} onUnlock={handleUnlock} />
                
                {/* Already Registered / Direct Access Link */}
                <div className="text-center mt-12 mb-8 animate-fade-in">
                  <button 
                    onClick={handleDirectAccess} 
                    className="group relative inline-flex flex-col items-center justify-center gap-2 p-4 transition-transform duration-300 hover:scale-[1.02] cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-industrial text-[11px] sm:text-xs text-slate-400 group-hover:text-[#FF8C00] transition-colors duration-300 tracking-[0.2em] uppercase">
                        Already Registered? Click here to download Checklist
                      </span>
                      <div className="w-6 h-6 rounded-full border border-slate-300 group-hover:border-[#FF8C00] group-hover:bg-[#FF8C00] flex items-center justify-center transition-all duration-300 shadow-sm">
                        <svg className="w-3 h-3 text-slate-400 group-hover:text-white transition-colors duration-300 transform group-hover:translate-x-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                        </svg>
                      </div>
                    </div>
                    <div className="w-full h-[2px] bg-[linear-gradient(90deg,transparent_0%,#cbd5e1_50%,transparent_100%)] bg-[length:200%_100%] group-hover:bg-[linear-gradient(90deg,transparent_0%,#FF8C00_50%,transparent_100%)] animate-shimmer opacity-50 group-hover:opacity-100 transition-all duration-500"></div>
                  </button>
                </div>
            </section>
          </section>
        </main>

        {/* Mobile Sticky Action Bar */}
        <div className="fixed bottom-0 left-0 right-0 p-4 sm:p-6 bg-white/80 backdrop-blur-xl sticky-btn-shadow z-50 animate-fade-in border-t border-slate-100 xl:hidden">
          <div className="max-w-xl mx-auto flex flex-col items-center gap-3">
             <Button 
                onClick={handleDownloadClick}
                variant="primary"
                className="w-full py-5 text-white bg-[#FF8C00] border-none shadow-[0_15px_30px_-5px_rgba(255,140,0,0.3)] font-black text-xs sm:text-sm tracking-[0.15em] rounded-xl hover:scale-[1.02] active:scale-[0.98] transition-transform"
              >
                {lang === 'en' ? 'Download SNR Homeowner’s Shield Checklist' : 'Descargar Lista de Control SNR'}
              </Button>
          </div>
        </div>

        {/* Mobile Static Share Links */}
        <div className="bg-white border-t border-slate-200 p-4 flex flex-wrap justify-between items-center xl:hidden print:hidden">
           <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mr-2 w-full text-center mb-2 sm:w-auto sm:mb-0">Share Checklist:</span>
           <div className="flex justify-center gap-4 w-full sm:w-auto">
              <button onClick={() => handleShare('facebook')} className="text-blue-600"><svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></button>
              <button onClick={() => handleShare('twitter')} className="text-slate-900"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></button>
              <button onClick={() => handleShare('linkedin')} className="text-[#0077b5]"><svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z"/></svg></button>
              <button onClick={() => handleShare('whatsapp')} className="text-[#25D366]"><svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.355-5.233c-.002-5.45 4.43-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
         </button>
      </div>

    </div>
  );
};