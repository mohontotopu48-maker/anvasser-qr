import React from 'react';
import { ChecklistItem, Language } from '../types';
import { uiContent } from '../data';
import { trackEvent } from '../utils/tracking';

interface ChecklistCardProps {
  item: ChecklistItem;
  lang: Language;
}

export const ChecklistCard: React.FC<ChecklistCardProps> = ({ item, lang }) => {
  const labels = uiContent[lang].standardLabels;

  const handleShare = (platform: 'facebook' | 'twitter' | 'linkedin' | 'email' | 'whatsapp' | 'copy') => {
    trackEvent('card_share_click', { platform, card_id: item.id });

    // Use the current page URL (clean)
    const pageUrl = window.location.href.split('?')[0];
    
    // Construct the share text including the specific mistake title
    const shareTitle = `Avoid Roofing Mistake #${item.id}: ${item.title}`;
    const shareBody = `I found this critical roofing mistake to avoid in the SNEWROOF Shield Checklist:\n\n"${item.mistake}"\n\nSee the full checklist here:`;

    if (platform === 'copy') {
      const shareText = `${shareTitle} - ${shareBody} ${pageUrl}`;
      navigator.clipboard.writeText(shareText);
      alert('Link copied to clipboard!');
      return;
    }

    const urlEncoded = encodeURIComponent(pageUrl);
    const titleEncoded = encodeURIComponent(shareTitle);
    const bodyEncoded = encodeURIComponent(shareBody);
    
    let shareUrl = '';
    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${urlEncoded}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${titleEncoded}&url=${urlEncoded}`;
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${urlEncoded}&title=${titleEncoded}&summary=${encodeURIComponent(item.mistake)}`;
        break;
      case 'whatsapp':
        shareUrl = `https://api.whatsapp.com/send?text=${titleEncoded}%0A%0A${bodyEncoded}%20${urlEncoded}`;
        break;
      case 'email':
        shareUrl = `mailto:?subject=${titleEncoded}&body=${bodyEncoded}%20${urlEncoded}`;
        break;
    }
    if (shareUrl) window.open(shareUrl, '_blank', 'width=600,height=400');
  };

  return (
    <div className="bg-white rounded-[24px] shadow-sm border border-slate-100 overflow-hidden relative break-inside-avoid mb-8 print:shadow-none print:border-none print:mb-12 group transition-shadow duration-300 hover:shadow-md">
      
      {/* Decorative Top Line - PDF Style */}
      <div className="h-1.5 w-full bg-[#FF8C00]"></div>

      <div className="p-6 sm:p-10 print:px-0 print:py-4">
        
        {/* Branding Logo (Watermark) - Updated to official logo */}
        <div className="absolute top-6 right-6 opacity-20 select-none hidden sm:block pointer-events-none filter grayscale contrast-125">
             <img 
               src="https://i.ibb.co/sJwRFxbT/snr-new-logo-2026-sc-sm.png" 
               alt="SNEWROOF Watermark" 
               className="w-24 h-auto"
             />
        </div>

        {/* Header Section: Number + Title */}
        <div className="flex flex-row items-start gap-4 mb-6 sm:mb-8">
          {/* Huge Number - Responsive Size */}
          <span className="text-5xl sm:text-7xl font-black text-[#f1f5f9] leading-none tracking-tighter select-none print:text-slate-200">
            {item.id.toString().padStart(2, '0')}
          </span>
          
          {/* Title - Responsive Size */}
          <h3 className="text-xl sm:text-3xl font-bold text-[#0052cc] leading-tight pt-1 sm:pt-2 print:text-[#0052cc]">
            {item.title}
          </h3>
        </div>

        {/* Content Body */}
        <div className="space-y-6 pl-0 sm:pl-4">
           
           {/* The Mistake */}
           <div className="flex gap-4 group/item">
              <div className="flex-shrink-0 mt-1">
                 <div className="w-5 h-5 rounded-full border border-[#FF8C00] text-[#FF8C00] flex items-center justify-center">
                    <span className="text-[10px] font-bold">!</span>
                 </div>
              </div>
              <div>
                <h4 className="text-[#FF8C00] font-bold text-sm sm:text-base mb-1">{labels.mistake}</h4>
                <p className="text-slate-600 font-medium leading-relaxed text-sm sm:text-base">
                   {item.mistake}
                </p>
              </div>
           </div>

           {/* The Danger */}
           {item.danger && (
             <div className="flex gap-4">
                <div className="flex-shrink-0 mt-1">
                   <div className="w-5 h-5 rounded-full bg-[#FF8C00] text-white flex items-center justify-center shadow-sm">
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                   </div>
                </div>
                <div>
                  <h4 className="text-[#FF8C00] font-bold text-sm sm:text-base mb-1">{labels.danger}</h4>
                  <p className="text-slate-600 font-medium leading-relaxed text-sm sm:text-base">
                     {item.danger}
                  </p>
                </div>
             </div>
           )}

           {/* The SNEWROOF Standard - PDF Style Box */}
           <div className="mt-8 bg-[#e8f4fe] rounded-2xl p-5 sm:p-8 flex gap-4 sm:gap-5 relative overflow-hidden print:bg-[#e8f4fe] print:break-inside-avoid">
              <div className="flex-shrink-0 relative z-10">
                 <div className="w-8 h-8 bg-[#0052cc] rounded-full flex items-center justify-center text-white shadow-md">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                 </div>
              </div>
              <div className="relative z-10">
                <h4 className="text-[#0052cc] font-bold text-base sm:text-lg mb-2">{labels.standard}</h4>
                <p className="text-[#1e293b] text-sm sm:text-base leading-relaxed font-medium">
                   {item.standard}
                </p>
              </div>
              {/* Subtle background decoration */}
              <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/20 rounded-full blur-2xl z-0 pointer-events-none"></div>
           </div>
        </div>

        {/* Action Buttons (Share) - Optimized for mobile touch (w-10 h-10) */}
        <div className="mt-6 flex flex-wrap items-center justify-between sm:justify-end gap-3 print:hidden pt-4 border-t border-slate-50">
            <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest mr-2">Share this tip:</span>
            
            <div className="flex gap-2">
                <button onClick={() => handleShare('facebook')} className="w-10 h-10 rounded-full bg-slate-50 hover:bg-blue-50 flex items-center justify-center text-slate-400 hover:text-blue-600 transition-colors" aria-label="Share on Facebook">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                </button>
                
                <button onClick={() => handleShare('twitter')} className="w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-black transition-colors" aria-label="Share on X (Twitter)">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                </button>

                <button onClick={() => handleShare('linkedin')} className="w-10 h-10 rounded-full bg-slate-50 hover:bg-blue-50 flex items-center justify-center text-slate-400 hover:text-[#0077b5] transition-colors" aria-label="Share on LinkedIn">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z"/></svg>
                </button>

                <button onClick={() => handleShare('whatsapp')} className="w-10 h-10 rounded-full bg-slate-50 hover:bg-green-50 flex items-center justify-center text-slate-400 hover:text-[#25D366] transition-colors" aria-label="Share on WhatsApp">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.355-5.233c-.002-5.45 4.43-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
                </button>

                <button onClick={() => handleShare('email')} className="w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-800 transition-colors" aria-label="Share via Email">
                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                </button>
            </div>
        </div>
      </div>

    </div>
  );
};