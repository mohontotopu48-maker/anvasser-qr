import React from 'react';
import { Language } from '../types';
import { uiContent } from '../data';
import { Button } from './Button';

interface HeaderProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onBook: () => void;
}

export const Header: React.FC<HeaderProps> = ({ lang, onLanguageChange, onBook }) => {
  const content = uiContent[lang];

  return (
    <header className="pt-14 pb-16 px-6 bg-[#0B0F19] border-b border-white/5 relative overflow-hidden">
      {/* Background Decorative Elements - Dark Theme */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#FF8C00] rounded-full blur-[150px] opacity-[0.08] -translate-y-1/2 translate-x-1/4 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-900 rounded-full blur-[150px] opacity-[0.1] translate-y-1/3 -translate-x-1/4 pointer-events-none"></div>
      
      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.05] pointer-events-none"></div>

      <div className="container max-w-xl mx-auto flex flex-col items-center text-center relative z-10">
        {/* SNEWROOF Badge Logo - Enhanced with Glow for Dark Background */}
        <div className="mb-10 transition-transform duration-500 hover:scale-105 active:scale-95 cursor-pointer relative group w-full flex justify-center">
           {/* Back Glow */}
           <div className="absolute inset-0 bg-[#FF8C00] rounded-full blur-3xl opacity-20 group-hover:opacity-30 transition-opacity duration-500 w-2/3 mx-auto"></div>
           
           <img 
             src="https://i.ibb.co/sJwRFxbT/snr-new-logo-2026-sc-sm.png" 
             alt="SNEWROOF Shield Logo" 
             className="relative z-10 w-full max-w-[280px] sm:max-w-sm h-auto object-contain filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.5)]"
           />
        </div>

        {/* Industrial Branding */}
        <div className="flex items-center gap-3 mb-5 opacity-80">
            <div className="h-[1px] w-8 bg-gradient-to-r from-transparent to-[#FF8C00]"></div>
            <h1 className="font-industrial text-[10px] sm:text-xs tracking-[0.4em] text-slate-400 uppercase text-center">
              SNR Homeowner’s Shield Protocol
            </h1>
            <div className="h-[1px] w-8 bg-gradient-to-l from-transparent to-[#FF8C00]"></div>
        </div>
        
        {/* Subtitle */}
        <h2 className="text-3xl sm:text-4xl font-black leading-tight tracking-tight text-white mb-8 max-w-lg drop-shadow-lg">
          20 Expensive Mistakes to Avoid <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF8C00] to-[#FFD700]">When Hiring a Roofer</span>
        </h2>

        {/* Primary Booking CTA in Header */}
        <div className="mb-12 w-full flex justify-center">
           <Button onClick={onBook} size="lg" className="bg-[#FF8C00] hover:bg-[#ff9d2e] text-black border border-orange-400/50 shadow-[0_0_30px_rgba(255,140,0,0.3)] text-sm sm:text-base px-10 rounded-2xl w-full sm:w-auto">
              {lang === 'en' ? 'Book Free Inspection' : 'Inspección Gratis'}
           </Button>
        </div>

        {/* Minimal Language Switcher */}
        <div className="flex items-center gap-6 text-[10px] font-bold tracking-widest text-slate-500 border border-white/10 px-6 py-2 rounded-full bg-white/5 backdrop-blur-sm">
          <button 
            onClick={() => onLanguageChange('en')}
            className={`transition-all duration-300 ${lang === 'en' ? 'text-white scale-105' : 'hover:text-slate-300'}`}
          >
            ENGLISH
            {lang === 'en' && <div className="h-0.5 w-full bg-[#FF8C00] mt-0.5 rounded-full shadow-[0_0_8px_#FF8C00]"></div>}
          </button>
          <div className="w-[1px] h-3 bg-white/10"></div>
          <button 
            onClick={() => onLanguageChange('es')}
            className={`transition-all duration-300 ${lang === 'es' ? 'text-white scale-105' : 'hover:text-slate-300'}`}
          >
            ESPAÑOL
            {lang === 'es' && <div className="h-0.5 w-full bg-[#FF8C00] mt-0.5 rounded-full shadow-[0_0_8px_#FF8C00]"></div>}
          </button>
        </div>
      </div>
    </header>
  );
};