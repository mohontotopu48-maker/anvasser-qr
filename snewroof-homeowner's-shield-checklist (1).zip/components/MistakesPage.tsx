import React, { useEffect } from 'react';
import { ChecklistCard } from './ChecklistCard';
import { checklistData } from '../data';
import { Language } from '../types';
import { Button } from './Button';
import { trackEvent } from '../utils/tracking';
import { Header } from './Header';

interface MistakesPageProps {
  lang: Language;
}

// Google Drive Direct Download Link
const PDF_DOWNLOAD_ID = "1ONC_7b0fqaqwhF8O4txwE-ztMhUlKGlx";
const PDF_DIRECT_LINK = `https://drive.google.com/uc?export=download&id=${PDF_DOWNLOAD_ID}`;

export const MistakesPage: React.FC<MistakesPageProps> = ({ lang }) => {
  const allItems = checklistData[lang];
  const BOOKING_URL = "https://api.leadconnectorhq.com/widget/bookings/free-roof-inspection-snewroof";

  // Scroll to top on mount and attempt auto-download
  useEffect(() => {
    window.scrollTo(0, 0);
    trackEvent('page_view_mistakes_full', { language: lang });

    // Auto-download logic using hidden iframe to prevent page navigation/replacement
    const timer = setTimeout(() => {
       const iframe = document.createElement('iframe');
       iframe.style.display = 'none';
       iframe.src = PDF_DIRECT_LINK;
       document.body.appendChild(iframe);
       
       // Clean up after a minute
       setTimeout(() => {
         if (document.body.contains(iframe)) {
           document.body.removeChild(iframe);
         }
       }, 60000);
    }, 1500);

    return () => clearTimeout(timer);
  }, [lang]);

  const handleDownload = () => {
    trackEvent('download_pdf_click');
    // Open in new tab to force download without navigating away
    window.open(PDF_DIRECT_LINK, '_blank');
  };
  
  const handleBook = () => {
    trackEvent('book_inspection_click', { location: 'full_checklist_page' });
    window.location.href = BOOKING_URL;
  }

  const handleShare = (platform: 'facebook' | 'twitter' | 'linkedin' | 'email' | 'whatsapp' | 'copy') => {
    trackEvent('share_click', { platform, location: 'full_checklist_sticky_bar' });
    
    const url = window.location.href.split('?')[0]; // Share clean URL
    const text = "Protect your home equity. 20 Expensive Mistakes to Avoid When Hiring a Roofer - The SNEWROOF Shield Checklist.";
    
    if (platform === 'copy') {
      navigator.clipboard.writeText(url);
      alert('Link copied to clipboard!');
      return;
    }

    let shareUrl = '';
    switch (platform) {
      case 'facebook': shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`; break;
      case 'twitter': shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`; break;
      case 'linkedin': shareUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(url)}&title=${encodeURIComponent("SNR Shield Checklist")}&summary=${encodeURIComponent(text)}`; break;
      case 'whatsapp': shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text + " " + url)}`; break;
      case 'email': shareUrl = `mailto:?subject=Important Homeowner Guide&body=${encodeURIComponent(text + "\n\n" + url)}`; break;
    }
    if (shareUrl) window.open(shareUrl, '_blank', 'width=600,height=400');
  };

  return (
    <div className="min-h-screen bg-white pb-20 font-sans text-slate-800">
      {/* Reusing the Header for Consistent Branding */}
      <Header lang={lang} onLanguageChange={() => {}} onBook={handleBook} />

      {/* Hero / Success Message */}
      <section className="bg-slate-50 border-b border-slate-200 pt-8 sm:pt-10 pb-12 sm:pb-16 px-4 sm:px-6 relative overflow-hidden">
         <div className="container max-w-2xl mx-auto text-center relative z-10">
            <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-bold tracking-widest uppercase mb-4 sm:mb-6 animate-fade-in">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
              Access Granted
            </div>
            
            <h1 className="text-2xl sm:text-4xl font-black text-slate-900 mb-3 sm:mb-4 animate-fade-in leading-tight">
               Your Shield is Ready.
            </h1>
            <p className="text-sm sm:text-base text-slate-600 mb-6 sm:mb-8 max-w-lg mx-auto leading-relaxed animate-fade-in">
               The official PDF checklist has been generated. Click the button below to save it to your device, or scroll down to read the mistakes online.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center animate-fade-in px-4 sm:px-0">
                <Button onClick={handleDownload} size="lg" className="w-full sm:w-auto shadow-xl bg-[#FF8C00] hover:bg-orange-600 text-white border-none group relative overflow-hidden">
                   <span className="relative z-10 flex items-center justify-center gap-2">
                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                     Download Official PDF
                   </span>
                   {/* Shine effect */}
                   <div className="absolute inset-0 -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/20 to-transparent z-0"></div>
                </Button>
                
                <Button onClick={handleBook} variant="dark" size="lg" className="w-full sm:w-auto shadow-lg">
                   Book Free Audit
                </Button>
            </div>
         </div>
         
         {/* Background Patterns */}
         <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
      </section>

      {/* Full Checklist Content */}
      <main className="container max-w-3xl mx-auto px-4 sm:px-6 py-10 sm:py-16">
         <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-xl sm:text-2xl font-black text-slate-800 uppercase tracking-tight">The 20-Point Protocol</h2>
            <div className="w-16 h-1 bg-[#FF8C00] mx-auto mt-4 rounded-full"></div>
         </div>

         <div className="space-y-4">
            {allItems.map((item, idx) => (
               <div key={item.id} className="animate-fade-in" style={{ animationDelay: `${idx * 50}ms` }}>
                  <ChecklistCard item={item} lang={lang} />
               </div>
            ))}
         </div>

         {/* Bottom CTA - Redesigned to Match Image Style */}
         <div className="mt-12 sm:mt-20 mx-auto max-w-4xl">
            <div className="bg-[#0f172a] rounded-[24px] sm:rounded-[32px] p-6 sm:p-12 shadow-2xl relative overflow-hidden group border border-slate-800/50">
                {/* Background Glow */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-[#1e293b] rounded-full blur-[120px] opacity-40 pointer-events-none -translate-y-1/2 translate-x-1/2"></div>
                <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-900/20 rounded-full blur-[80px] pointer-events-none translate-y-1/3 -translate-x-1/3"></div>
                
                {/* Content Section */}
                <div className="relative z-10">
                    <div className="flex flex-col md:flex-row gap-6 sm:gap-8 items-start mb-6 sm:mb-10">
                        {/* Icon */}
                        <div className="flex-shrink-0">
                             <div className="w-12 h-12 md:w-16 md:h-16 rounded-2xl bg-blue-600 flex items-center justify-center shadow-[0_0_25px_rgba(37,99,235,0.4)] transform rotate-3">
                                <svg className="w-5 h-5 md:w-8 md:h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                             </div>
                        </div>
                        
                        <div>
                             <h4 className="text-blue-400 font-bold tracking-[0.2em] text-[10px] sm:text-xs uppercase mb-2 sm:mb-3">
                                The SNEWROOF Standard
                             </h4>
                             <h3 className="text-lg sm:text-xl md:text-3xl font-bold text-white leading-tight">
                                We prioritize your protection over our convenience. <br/>
                                <span className="text-slate-400 font-medium text-sm md:text-lg mt-3 block leading-relaxed">
                                   Don't risk your home equity on a "guess." Secure your home with a certified SNEWROOF Shield Inspection today.
                                </span>
                             </h3>
                        </div>
                    </div>

                    {/* Divider */}
                    <div className="h-px w-full bg-gradient-to-r from-slate-800 via-slate-700 to-slate-800 mb-6 sm:mb-8"></div>

                    {/* Action Row */}
                    <div className="flex flex-col md:flex-row items-center justify-between gap-6 sm:gap-8">
                         {/* Share (Left) */}
                         <div className="flex items-center gap-4 w-full md:w-auto justify-center md:justify-start">
                             <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Share Mistake:</span>
                             <div className="flex gap-2">
                                <button onClick={() => handleShare('facebook')} className="w-10 h-10 rounded-full bg-[#1e293b] hover:bg-blue-600 text-slate-400 hover:text-white flex items-center justify-center transition-all border border-slate-700 hover:border-blue-500">
                                   <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                                </button>
                                <button onClick={() => handleShare('twitter')} className="w-10 h-10 rounded-full bg-[#1e293b] hover:bg-black text-slate-400 hover:text-white flex items-center justify-center transition-all border border-slate-700 hover:border-slate-500">
                                   <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                                </button>
                                <button onClick={() => handleShare('linkedin')} className="w-10 h-10 rounded-full bg-[#1e293b] hover:bg-[#0077b5] text-slate-400 hover:text-white flex items-center justify-center transition-all border border-slate-700 hover:border-[#0077b5]">
                                   <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z"/></svg>
                                </button>
                                <button onClick={() => handleShare('email')} className="w-10 h-10 rounded-full bg-[#1e293b] hover:bg-slate-200 hover:text-slate-900 text-slate-400 flex items-center justify-center transition-all border border-slate-700 hover:border-slate-300">
                                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                                </button>
                             </div>
                         </div>

                         {/* Button (Right) */}
                         <Button 
                             onClick={handleBook} 
                             className="bg-[#FF8C00] hover:bg-[#ff9d2e] text-black font-black text-xs sm:text-sm px-6 sm:px-12 py-5 !rounded-2xl shadow-[0_0_30px_rgba(255,140,0,0.3)] hover:shadow-[0_0_50px_rgba(255,140,0,0.5)] transition-all transform hover:-translate-y-1 w-full md:w-auto flex items-center justify-center gap-3"
                         >
                             <span className="leading-tight text-center sm:text-left">HIRE SNEWROOF &<br className="hidden sm:block" /> AVOID MISTAKES</span>
                             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                         </Button>
                    </div>
                </div>
            </div>
         </div>
      </main>

      {/* Floating Share Bar (Desktop) - Reused */}
      <div className="fixed left-6 top-1/2 -translate-y-1/2 z-40 hidden xl:flex flex-col gap-3 bg-white p-3 rounded-2xl shadow-[0_5px_30px_rgba(0,0,0,0.1)] border border-slate-100 animate-fade-in print:hidden">
         <span className="text-[10px] font-bold text-slate-400 text-center uppercase tracking-widest writing-vertical-lr py-2">Share Guide</span>
         
         <button onClick={() => handleShare('facebook')} className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center" title="Share on Facebook">
           <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
         </button>
         
         <button onClick={() => handleShare('twitter')} className="w-10 h-10 rounded-full bg-slate-50 text-slate-900 hover:bg-black hover:text-white transition-all flex items-center justify-center" title="Share on X (Twitter)">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
         </button>
         
         <button onClick={() => handleShare('linkedin')} className="w-10 h-10 rounded-full bg-blue-50 text-[#0077b5] hover:bg-[#0077b5] hover:text-white transition-all flex items-center justify-center" title="Share on LinkedIn">
           <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z"/></svg>
         </button>

         <button onClick={() => handleShare('whatsapp')} className="w-10 h-10 rounded-full bg-green-50 text-[#25D366] hover:bg-[#25D366] hover:text-white transition-all flex items-center justify-center" title="Share on WhatsApp">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.355-5.233c-.002-5.45 4.43-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
         </button>
      </div>

    </div>
  );
};