import React, { useState, useEffect } from 'react';
import { Language } from '../types';
import { uiContent } from '../data';
import { trackEvent } from '../utils/tracking';

interface LeadFormProps {
  lang: Language;
  onUnlock?: () => void;
}

export const LeadForm: React.FC<LeadFormProps> = ({ lang, onUnlock }) => {
  const content = uiContent[lang];
  const labels = content.formLabels;
  const [isLoading, setIsLoading] = useState(true);
  const [loadCount, setLoadCount] = useState(0);

  // Listener for Iframe Load (Fallback method)
  const handleLoad = () => {
    setIsLoading(false);
    const newCount = loadCount + 1;
    setLoadCount(newCount);

    if (newCount === 1) {
      // First load: Form is ready
      trackEvent('lead_form_loaded');
    } else if (newCount > 1) {
      // Second load: Submission likely occurred (iframe redirected to Thank You page)
      trackEvent('lead_form_submitted_detected_load');
      if (onUnlock) {
        onUnlock();
      }
    }
  };

  // Listener for PostMessage (Primary "Fast" method)
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      try {
        const data = event.data;
        
        // Check for various GHL/LeadConnector submission signals
        // They typically send { action: 'form_submitted', ... } or similar structure
        const isSubmission = 
          (data && data.action === 'form_submitted') || 
          (data && data.type === 'form-submit') ||
          (typeof data === 'string' && data.includes('form_submitted'));

        if (isSubmission) {
          trackEvent('lead_form_submitted_detected_message');
          if (onUnlock) {
            onUnlock();
          }
        }
      } catch (e) {
        // Ignore parsing errors from other sources
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onUnlock]);

  return (
    <div className="relative max-w-md mx-auto transform transition-all hover:scale-[1.02] duration-500 group">
        {/* Glow Effect - Pulsing & Animated */}
        <div className="absolute -inset-1.5 bg-gradient-to-r from-[#FF8C00] via-yellow-500 to-[#FF8C00] rounded-3xl blur-md opacity-40 group-hover:opacity-75 transition duration-1000 animate-pulse-glow"></div>
        
        <div className="relative bg-white rounded-2xl shadow-2xl overflow-hidden ring-1 ring-black/5">
            
            {/* Premium Header - Dark Theme for Contrast - Matches Main Header */}
            <div className="bg-[#0B0F19] text-white p-8 text-center relative overflow-hidden">
                {/* Abstract Shine */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF8C00] rounded-full blur-[60px] opacity-20 -translate-y-1/2 translate-x-1/2 group-hover:animate-pulse"></div>
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>

                {/* Top Accent Line */}
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#FF8C00] via-yellow-500 to-[#FF8C00]"></div>
                
                {/* Logo */}
                <div className="relative z-10 mx-auto mb-6 transition-transform duration-500 hover:scale-105">
                    <img 
                      src="https://i.ibb.co/sJwRFxbT/snr-new-logo-2026-sc-sm.png" 
                      alt="SNEWROOF Shield" 
                      className="h-16 w-auto mx-auto object-contain filter drop-shadow-[0_0_15px_rgba(255,140,0,0.4)]" 
                    />
                </div>

                <h3 className="relative z-10 text-2xl font-black tracking-tight uppercase mb-2 leading-none group-hover:text-white transition-colors">
                    {labels.sectionTitle}
                </h3>
                <p className="relative z-10 text-slate-400 text-xs font-bold uppercase tracking-widest max-w-xs mx-auto group-hover:text-slate-300 transition-colors">
                    {labels.sectionDesc}
                </p>
            </div>

            {/* Value Props Strip */}
            <div className="bg-orange-50/80 backdrop-blur-sm border-b border-orange-100/50 px-4 py-3 flex justify-between items-center text-[9px] sm:text-[10px] font-bold text-orange-900/80 uppercase tracking-widest">
                <span className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
                    Instant PDF
                </span>
                <span className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" style={{ animationDelay: '150ms' }}></div>
                    Full Guide
                </span>
                <span className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" style={{ animationDelay: '300ms' }}></div>
                    Secure
                </span>
            </div>

            {/* Form Container */}
            <div className="relative min-h-[480px] bg-white">
                 {isLoading && (
                    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-white">
                        <div className="w-10 h-10 border-4 border-slate-100 border-t-[#FF8C00] rounded-full animate-spin mb-3"></div>
                        <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] animate-pulse">Loading Secure Portal</span>
                    </div>
                )}
                 <iframe
                    src="https://api.leadconnectorhq.com/widget/form/VFhddxSY6ekpTfh5pzZy?notrack=true"
                    style={{ width: '100%', border: 'none', height: '100%', minHeight: '500px' }}
                    id="ghl-form-iframe"
                    title="Unlock Checklist"
                    scrolling="no"
                    onLoad={handleLoad}
                 />
            </div>
            
             {/* Security Footer */}
            <div className="bg-[#f8f9fa] py-3 text-center border-t border-slate-100">
                <div className="flex items-center justify-center gap-1.5 opacity-60 hover:opacity-100 transition-opacity">
                    <svg className="w-3 h-3 text-slate-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd"></path></svg>
                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">256-Bit SSL Secured</span>
                </div>
            </div>
        </div>
    </div>
  );
};